# NexBar2 SteamOS package

NexBar2 maps Steam's 17 logical front-bar LEDs to the 24 WS2812B LEDs in a NexGen3D Redux chassis through a Nollie1 controller.

## Preferred signal path

`Steam Game Mode Personalization -> valve-leds[0..16] shim -> nexbar-bridge.py -> 17-to-24 mapping -> Nollie1 hidraw`

The shim is the important change from NexBar1. When Steam writes it, Steam owns ordinary color, brightness, effects, and manual pixel frames. The bridge only translates that state to the physical strip and applies the safety override. If the shim is absent or never advances beyond its initialization snapshot, NexBar falls back to its CEF/ACF download observer and configured idle behavior.

## First install

From Desktop Mode, unpack `nexbar.zip` and run:

```bash
./install.sh
```

The installer preserves an existing config, installs the user service, adds Nollie/shim udev rules, enables the Steam CEF fallback marker, and builds the GPL Valve-compatible shim when matching kernel headers are present.

After installation restart Steam once, open **Settings > Personalization** in Game Mode, and change a light-bar setting. Then check:

```bash
journalctl --user -u nexbar -f
```

Native success means the control page reports `steam-native`, the shim sequence is greater than 1, and the sequence changes when you alter a setting in Steam.

## Normal NexBar update

Python-only updates do **not** need a shim rebuild. Replace:

```text
~/.local/lib/nexbar/nexbar-bridge.py
```

with the new `nexbar-bridge.py`, then restart `nexbar.service` from the systemd user service manager. The kernel module only needs attention when the running SteamOS kernel changes or diagnostics report that the shim is missing/mismatched.

## Behavior

- Thermal override: **85 C trip / 80 C clear**, pure red.
- Boot fallback: Steam blue breathing, never white.
- Idle fallback: Steam blue, 25%, solid by default.
- Download fallback: filled region only; once progress is at least 10%, a quick activity pulse starts at physical LED 0 and travels only to the current filled edge about every 2 seconds. Paused downloads hold the fill with no pulse.
- Mapping: `stretch`, `nearest`, `center`, plus physical reverse.
- Direct hidraw is preferred. OpenRGB SDK on `127.0.0.1:6742` is fallback only.

Fremont RAM/GPU/SSD/memory-training POST colors are intentionally not emulated because the BC-250 firmware cannot truthfully expose those pre-userspace states to NexBar.

## Local control and diagnostics

Open `http://127.0.0.1:1873/` on the Steam Machine. It shows current owner, backend, shim state/sequence/age, download source/progress, temperature, and thermal latch. It configures fallback color/brightness, mapping, and pulse period. Steam Personalization remains the preferred ordinary color/effect UI when native writes work.

## Kernel updates

If `valve-leds[0]` through `[16]` disappear after an update, install the matching kernel headers and rerun:

```bash
./install.sh --with-shim
```

The shim source is GPL-2.0+ and its provenance is documented in `kernel/PROVENANCE.md`.

## Acceptance checklist on the Redux

1. `/sys/class/leds/valve-leds[0]` through `[16]` exist.
2. `/dev/valve-leds-shim` reads exactly 100 bytes and sequence advances past 1 after a Game Mode light-bar change.
3. Steam Personalization changes reach the Nollie strip.
4. A download is represented either by Steam manual pixels or by the fallback progress observer.
5. Pausing a fallback download stops the activity pulse immediately.
6. A test temperature at/above 85 C trips red and stays latched until at/below 80 C.
7. Direct hidraw remains lit for at least 120 seconds; the daemon rewrites MOS every ~1.5 seconds and frames continuously.
