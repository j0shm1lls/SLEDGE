#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA="$HOME/.local/lib/nexbar"
CONF="$HOME/.config/nexbar/nexbar.conf.json"
USER_UNITS="$HOME/.config/systemd/user"
CEF_MARKER="$HOME/.steam/steam/.cef-enable-remote-debugging"
WITH_SHIM=auto

for arg in "$@"; do
  case "$arg" in
    --with-shim) WITH_SHIM=yes ;;
    --without-shim) WITH_SHIM=no ;;
    --help) echo "Usage: ./install.sh [--with-shim|--without-shim]"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

say(){ printf '\n==> %s\n' "$*"; }
warn(){ printf 'WARN: %s\n' "$*" >&2; }

say "Installing NexBar2 daemon"
mkdir -p "$DATA" "$(dirname "$CONF")" "$USER_UNITS"
install -m 0755 "$HERE/nexbar-bridge.py" "$DATA/nexbar-bridge.py"
if [[ ! -f "$CONF" ]]; then
  install -m 0644 "$HERE/nexbar.conf.json" "$CONF"
  echo "Created $CONF"
else
  echo "Preserved existing $CONF"
fi
install -m 0644 "$HERE/nexbar.service" "$USER_UNITS/nexbar.service"
install -m 0644 "$HERE/openrgb.service" "$USER_UNITS/openrgb.service"

mkdir -p "$(dirname "$CEF_MARKER")"
if [[ ! -e "$CEF_MARKER" ]]; then
  : > "$CEF_MARKER"
  warn "Enabled Steam CEF debugging fallback. Restart Steam once if native LED writes are unavailable."
fi

install_root_files(){
  local toggled=0
  if command -v steamos-readonly >/dev/null 2>&1; then
    if sudo steamos-readonly status 2>/dev/null | grep -qi enabled; then
      sudo steamos-readonly disable
      toggled=1
    fi
  fi
  sudo install -m 0644 "$HERE/kernel/99-nexbar.rules" /etc/udev/rules.d/99-nexbar.rules
  sudo udevadm control --reload-rules || true
  sudo udevadm trigger --subsystem-match=hidraw || true

  local kdir="/lib/modules/$(uname -r)/build"
  if [[ "$WITH_SHIM" != no && -d "$kdir" && -f "$kdir/Makefile" ]]; then
    say "Building Valve-compatible LED shim for $(uname -r)"
    make -C "$HERE/kernel" clean >/dev/null 2>&1 || true
    make -C "$HERE/kernel"
    sudo install -D -m 0644 "$HERE/kernel/leds-valve-shim.ko" "/lib/modules/$(uname -r)/updates/leds-valve-shim.ko"
    sudo depmod -a
    sudo modprobe -r leds-valve-shim 2>/dev/null || true
    sudo modprobe leds-valve-shim
    echo "Shim loaded. Steam Game Mode can now probe valve-leds[0..16]."
  elif [[ "$WITH_SHIM" == yes ]]; then
    warn "Kernel headers are missing for $(uname -r); cannot build the requested shim."
  else
    warn "Kernel headers not available; daemon will use fallback behavior until the shim is built."
  fi

  if [[ "$toggled" == 1 ]]; then
    sudo steamos-readonly enable
  fi
}

say "Installing hardware permissions and Steam-native shim when possible"
if command -v sudo >/dev/null 2>&1; then
  install_root_files
else
  warn "sudo is unavailable. Copy kernel/99-nexbar.rules and build the shim manually for Steam-native control."
fi

say "Starting user service"
systemctl --user daemon-reload
systemctl --user enable --now nexbar.service
if command -v loginctl >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
  sudo loginctl enable-linger "$USER" 2>/dev/null || true
fi

echo
echo "NexBar2 installed."
echo "Control/diagnostics: http://127.0.0.1:1873/"
echo "Logs: journalctl --user -u nexbar -f"
echo "Game Mode: Settings > Personalization. Native control is active only after shim seq advances beyond initialization."
